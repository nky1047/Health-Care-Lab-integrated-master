export class MyTest{
    testId: Number;
	testName: String;
	testDetails: String;
	testCost: Number;
}