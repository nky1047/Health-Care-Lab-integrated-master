export class MyDiagnosticCentre{
    diagnosticCentreId: Number;
	centreName: String;
	centreAddress: String;
}